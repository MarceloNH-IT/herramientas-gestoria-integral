# Changelog
Formato basado en [Keep a Changelog](https://keepachangelog.com/es-ES/1.1.0/) y [SemVer](https://semver.org/lang/es/).

## [Unreleased]
- Primer conector real (Posadas o Rosario).

## [0.1.0] - 2026-10-17
### Agregado
- Interfaz Streamlit con diseño tipo buscador (hero, pantalla de carga con progreso, resultados por jurisdicción, resumen flotante).
- Motor de consultas concurrente con `asyncio`, timeout y aislamiento de errores por portal.
- Configuración de 13 jurisdicciones con enlace al portal oficial.
- Validación de patentes (4 formatos).
- Modo demo con datos simulados (desactivado por defecto).
### Corregido
- Textos corruptos por codificación (ahora UTF-8).
- Incompatibilidades entre versiones de Streamlit (tablas propias en HTML).
### Eliminado
- Datos ficticios mostrados por defecto en la primera versión.
