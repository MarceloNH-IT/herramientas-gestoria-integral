# Uso responsable y aviso
- La información proviene de portales públicos oficiales; este proyecto **no está afiliado** a ningún organismo.
- Los resultados son **informativos** y pueden diferir del estado real: verificar siempre en el portal oficial.
- Cada conector debe revisar los términos de uso del sitio, limitar la frecuencia de consultas y no evadir protecciones de seguridad.
- Las patentes constituyen datos asociados a personas: no se almacenan consultas ni se registran en logs públicos (Ley 25.326 de Protección de Datos Personales).
