# Arquitectura

## Flujo
```
Formulario (patente) → normalizar_patente() → validación regex
        │
        ▼
ejecutar_consultas()  ── asyncio.create_task por jurisdicción ──┐
        │                                                       │
        │   _consultar_una(cfg): timeout 45 s, captura de error │
        ▼                                                       ▼
 ResultadoJurisdiccion  ◄──────────  cfg.consultar(patente) → list[Infraccion]
        │
        ▼
Renderizado: hero · resumen flotante · tablas por jurisdicción · portales manuales
```

## Modelos
- `Infraccion`: acta, descripción, monto, flag de controlador.
- `JurisdiccionConfig`: nombre, tipo de protección, URL, función `consultar` (opcional).
- `ResultadoJurisdiccion`: infracciones, estado de conexión, error, flag demo.

## Cómo agregar un conector
1. Escribir `async def scrap_xxx(patente: str) -> list[Infraccion]`.
2. Asignarla en `JURISDICCIONES` (`consultar=scrap_xxx`).
3. Guardar una respuesta real de ejemplo en `tests/fixtures/` y testear el parser.

## Principios
- **Sin datos inventados** en modo normal: una jurisdicción sin conector se informa como tal.
- **Fallas aisladas**: nunca una excepción de un portal rompe la consulta global.
