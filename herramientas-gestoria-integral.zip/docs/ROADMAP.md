# Roadmap

| Etapa | Objetivo | Estado |
|---|---|---|
| 0.1 | UI, motor asíncrono, mapa de 13 jurisdicciones | ✅ Hecho |
| 0.2 | Primer conector real sin CAPTCHA (Posadas o Rosario) | ⏳ Próximo |
| 0.3 | Conectores restantes sin CAPTCHA (Lomas, Córdoba) | ⬜ |
| 0.4 | Tests automáticos de parsers con respuestas guardadas (fixtures) | ⬜ |
| 0.5 | Caché de resultados y límite de consultas por portal | ⬜ |
| 0.6 | Evaluar vías oficiales para portales con captcha / Cloudflare | ⬜ |
| 1.0 | Exportación a PDF/Excel del informe por dominio | ⬜ |
