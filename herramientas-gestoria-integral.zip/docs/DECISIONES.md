# Registro de decisiones (ADR)

## ADR-001 — Streamlit como frontend
**Contexto:** herramienta interna de uso diario, un solo desarrollador.
**Decisión:** Streamlit. **Consecuencia:** desarrollo rápido; personalización visual vía CSS inyectado.

## ADR-002 — Consultas concurrentes con asyncio
**Decisión:** una tarea por jurisdicción con timeout y captura de errores. **Motivo:** los portales son lentos e independientes.

## ADR-003 — No mostrar datos simulados por defecto
**Contexto:** la primera versión mostraba multas ficticias. **Decisión:** modo demo opt-in y señalizado. **Motivo:** evitar confusión en un contexto de gestión real.

## ADR-004 — No eludir captchas
**Decisión:** para portales con captcha/Cloudflare se prioriza acceso oficial o consulta asistida, no evasión técnica. **Motivo:** respeto a términos de uso y riesgo legal.
