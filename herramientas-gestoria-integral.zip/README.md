# ⚖️ Herramientas de Gestoría Integral — Buscador de infracciones por patente

Aplicación web (Python + Streamlit) que unifica en una sola pantalla la consulta de infracciones de tránsito de **13 jurisdicciones argentinas**, pensada para el trabajo diario de una gestoría automotor.

> **Estado: en desarrollo (v0.1).** La interfaz y el motor de consultas están terminados; los conectores reales a cada portal se están integrando de a uno. Ver [ROADMAP](docs/ROADMAP.md).

<!-- Agregar capturas reales en docs/img/ y descomentar:
![Pantalla de búsqueda](docs/img/busqueda.png)
![Resultados](docs/img/resultados.png)
-->

## ¿Qué problema resuelve?
Consultar una patente implica entrar a decenas de portales municipales y provinciales, cada uno con su formato, su captcha y su criterio. Este proyecto busca centralizar esa consulta y mostrar un **resultado unificado con totales por jurisdicción**.

## Funcionalidades (v0.1)
- Validación y normalización de patentes (formatos `LLLNNN`, `LLNNNLL`, `LNNNLLL`, `NNNLLL`).
- Consulta **concurrente** a todas las jurisdicciones (`asyncio`), con barra de progreso.
- Aislamiento de fallas: un portal caído o lento (timeout 45 s) no afecta al resto.
- Resultados agrupados por jurisdicción, con resumen flotante y total general.
- Para jurisdicciones sin conector: acceso directo al portal oficial.
- Modo demo (datos simulados, **apagado por defecto** y señalizado en pantalla).

## Jurisdicciones relevadas

| Grupo | Jurisdicciones | Estrategia prevista |
|---|---|---|
| Sin CAPTCHA (4) | Posadas, Rosario, Lomas de Zamora, Córdoba Caminera | Conector automático (HTTP / Playwright) |
| reCAPTCHA / CAPTCHA texto (7) | PBA, CABA, Ezeiza, Entre Ríos, Misiones, Lanús, Santa Fe | Acceso oficial / consulta asistida; evaluar APIs oficiales |
| Cloudflare (2) | Vicente López, Avellaneda | Acceso oficial / consulta asistida |

## Instalación y uso
```bash
git clone https://github.com/MarceloNH-IT/herramientas-gestoria-integral.git
cd herramientas-gestoria-integral
python -m venv .venv
# Windows: .venv\Scripts\activate    |  Linux/Mac: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```
Requiere Python 3.10+. Los archivos deben guardarse en **UTF-8**.

## Arquitectura (resumen)
`JurisdiccionConfig` → función `consultar(patente)` por portal → `ejecutar_consultas()` (asyncio) → `ResultadoJurisdiccion` → renderizado. Detalle en [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Uso responsable
Este proyecto consulta información pública de portales oficiales. Los conectores deben respetar los términos de uso de cada sitio, limitar la frecuencia de consultas y **no eludir mecanismos de seguridad (captchas, protecciones anti-bot)**. Ver [docs/LEGAL.md](docs/LEGAL.md).

## Documentación
- [Bitácora de desarrollo](docs/bitacora/)
- [Changelog](CHANGELOG.md)
- [Roadmap](docs/ROADMAP.md)
- [Decisiones de arquitectura](docs/DECISIONES.md)

## Autor
Marcelo — [@MarceloNH-IT](https://github.com/MarceloNH-IT)

## Licencia
MIT — ver [LICENSE](LICENSE).
