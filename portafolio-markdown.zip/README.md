<!-- Este archivo va en un repositorio PÚBLICO llamado exactamente igual a tu usuario: MarceloNH-IT/MarceloNH-IT -->

# Hola, soy Marcelo 👋

**Gestor automotor que automatiza su propio trabajo con Python.**
Combino experiencia real en trámites y fiscalización vehicular con desarrollo de herramientas que ahorran tiempo y reducen errores.

📫 **Contacto:** [TU-EMAIL] · [LinkedIn](https://linkedin.com/in/TU-PERFIL)
📍 Argentina · 🗣️ Español (nativo) · English: [NIVEL]

---

## 🚀 Proyecto destacado

### ⚖️ Buscador unificado de infracciones por patente
Aplicación web que consolida la consulta de multas de **13 jurisdicciones argentinas** en una sola pantalla.

`Python` `Streamlit` `asyncio` `dataclasses`

| | |
|---|---|
| **Problema** | Consultar una patente exige entrar a muchos portales con formatos y protecciones distintas |
| **Solución** | Motor de consultas concurrentes con aislamiento de errores y resultado unificado |
| **Estado** | 🟡 v0.1 — interfaz y motor listos; conectores reales en integración |

👉 [Ver repositorio](https://github.com/MarceloNH-IT/herramientas-gestoria-integral) · [Caso de estudio](proyectos/gestoria-infracciones.md)

---

## 🛠️ Stack y herramientas

| Área | Tecnologías |
|---|---|
| Lenguajes | Python |
| Web / UI | Streamlit, HTML/CSS |
| Concurrencia | asyncio |
| Automatización (en aprendizaje) | requests, Playwright |
| Control de versiones | Git, GitHub |
| Entorno | Windows, PowerShell |

> Solo listo lo que uso en proyectos reales. Lo marco "en aprendizaje" cuando todavía lo estoy incorporando.

## 📈 Lo que estoy trabajando ahora
- [ ] Primer conector real sin CAPTCHA (Posadas / Rosario)
- [ ] Tests de parsers con respuestas guardadas
- [ ] Documentar cada avance en la [bitácora del proyecto](https://github.com/MarceloNH-IT/herramientas-gestoria-integral/tree/main/docs/bitacora)

## 📚 Portafolio
Todos mis proyectos y casos de estudio: **[Ver índice →](PORTFOLIO.md)**

## 🤝 Cómo trabajo
- Documento decisiones y errores, no solo resultados.
- Priorizo datos reales y trazables; no muestro información simulada como si fuera real.
- Respeto los términos de uso de las fuentes que consulto.
