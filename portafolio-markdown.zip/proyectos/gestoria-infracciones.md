# ⚖️ Buscador unificado de infracciones por patente

> **Estado:** 🟡 v0.1 · **Última actualización:** 2026-10-17
> **Repositorio:** https://github.com/MarceloNH-IT/herramientas-gestoria-integral

## 1. Contexto
En la gestoría, verificar las infracciones de un dominio implica consultar manualmente portales de distintos municipios y provincias.

## 2. Problema
- Cada portal tiene un formato, un flujo y un nivel de protección distinto (sin CAPTCHA, reCAPTCHA, CAPTCHA de texto, Cloudflare).
- El proceso manual es lento y propenso a omisiones.

## 3. Solución
Una aplicación web que recibe la patente, valida el formato y consulta **en paralelo** todas las jurisdicciones configuradas, mostrando un resultado unificado con subtotales y total general.

<!-- ![Pantalla de búsqueda](../assets/busqueda.png) -->
<!-- ![Resultados](../assets/resultados.png) -->

## 4. Decisiones técnicas
| Decisión | Motivo |
|---|---|
| Streamlit | Desarrollo rápido para herramienta interna |
| `asyncio` + timeout por portal | Portales lentos e independientes; una falla no debe romper el resto |
| Sin datos simulados por defecto | Evitar confusión en un contexto de gestión real |
| No eludir captchas | Respeto a términos de uso y riesgo legal |

## 5. Resultados hasta ahora
- ✅ Interfaz completa y validación de patentes (4 formatos).
- ✅ Motor concurrente probado con tests automáticos de la interfaz.
- ⏳ Conectores reales: **0 de 13** activos (próximo objetivo: Posadas o Rosario).

## 6. Dificultades y aprendizajes
- Problemas de codificación de caracteres → estandarizar en UTF-8.
- Confusión entre ejecutar scripts y pegar código en la terminal.
- Conflictos de Git (`non-fast-forward`) → sincronizar antes de publicar.
- Mostrar "sin datos" es mejor que mostrar datos inventados.

## 7. Próximos pasos
Ver [ROADMAP](https://github.com/MarceloNH-IT/herramientas-gestoria-integral/blob/main/docs/ROADMAP.md).
