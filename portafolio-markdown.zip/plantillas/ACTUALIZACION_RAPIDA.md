# Checklist al terminar una sesión (5 min)
1. Copiar `docs/bitacora/AAAA-MM-DD.md` en el repo del proyecto y completarlo.
2. Sumar una línea al `CHANGELOG.md`.
3. Actualizar el estado y los números en el caso de estudio.
4. Agregar el hito a la línea de tiempo de `PORTFOLIO.md`.
5. Si hay avance visible: capturar pantalla y guardarla en `assets/`.
6. `git add . && git commit -m "docs: actualización AAAA-MM-DD" && git push`
