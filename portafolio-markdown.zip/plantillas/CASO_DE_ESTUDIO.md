# [Nombre del proyecto]

> **Estado:** 🔵/🟡/🟢 · **Última actualización:** AAAA-MM-DD
> **Repositorio:** [enlace]

## 1. Contexto
## 2. Problema
## 3. Solución
(capturas o GIF)
## 4. Decisiones técnicas
| Decisión | Motivo |
|---|---|
## 5. Resultados (con números reales)
## 6. Dificultades y aprendizajes
## 7. Próximos pasos
