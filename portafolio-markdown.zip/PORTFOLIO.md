# 📂 Portafolio

Índice de proyectos, ordenados del más reciente al más antiguo. Cada uno tiene un caso de estudio con problema, solución, decisiones y aprendizajes.

## Proyectos

| Proyecto | Resumen | Tecnologías | Estado | Enlaces |
|---|---|---|---|---|
| ⚖️ **Buscador de infracciones por patente** | Consulta unificada de multas en 13 jurisdicciones | Python · Streamlit · asyncio | 🟡 En desarrollo (v0.1) | [Caso](proyectos/gestoria-infracciones.md) · [Repo](https://github.com/MarceloNH-IT/herramientas-gestoria-integral) |
<!-- Copiá una fila por cada proyecto nuevo -->

**Leyenda de estado:** 🟢 Terminado · 🟡 En desarrollo · 🔵 Idea / planificado · ⚪ Archivado

## Línea de tiempo

| Fecha | Hito |
|---|---|
| 2026-10-17 | Creación del repositorio, app v0.1 con interfaz y motor asíncrono, relevamiento de 13 portales |
<!-- Agregá una línea por cada hito importante, la más nueva arriba -->

## Habilidades demostradas
- **Análisis del problema:** relevamiento y clasificación de 13 portales por tipo de protección.
- **Diseño de software:** dataclasses, tipado, separación entre conectores y presentación.
- **Concurrencia:** consultas simultáneas con timeouts y aislamiento de fallas.
- **Frontend:** interfaz a medida sobre Streamlit con CSS.
- **Buenas prácticas:** control de versiones, documentación, changelog, decisiones registradas.
